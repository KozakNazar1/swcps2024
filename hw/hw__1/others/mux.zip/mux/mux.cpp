#include "systemc.h"
#include "mux.h"

void Mux::muxAction(){
  if (sel.read() == '1') {
      out.write(in2.read());
  }
  else if(sel.read() == '0') {
      out.write(in1.read());
  }
  else if (sel.read() == 'Z') {
      out.write('X');                   // ? (1)
      //out.write(in1.read());          // ? (2)
  }
  else { // else if (sel.read() == 'X')
      out.write('X');                   // ? (...)
  }
}


