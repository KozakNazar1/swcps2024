#ifndef MUX_H
#define MUX_H

struct Mux : sc_module {
    sc_in<sc_logic> in1;
    sc_in<sc_logic> in2;
    sc_in<sc_logic> sel;
    sc_out<sc_logic> out;

    void muxAction();

    SC_CTOR( Mux ) {
        SC_METHOD(muxAction);
        sensitive << in1 << in2 << sel;
    }

	public:

};

#endif
