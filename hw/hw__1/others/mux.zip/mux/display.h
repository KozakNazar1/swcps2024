#ifndef DISPLAY_H
#define DISPLAY_H 

struct Display : sc_module {
    sc_in_clk      clk;
    sc_in<sc_logic> in2;
    sc_in<sc_logic> in1;
    sc_in<sc_logic> sel;
    sc_in<sc_logic> out;
    
    void print();
    
    SC_CTOR(Display) {
        SC_METHOD( print );
        sensitive_pos << clk;
    }
};

#endif
