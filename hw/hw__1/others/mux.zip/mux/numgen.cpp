#include "systemc.h"
#include "numgen.h"

//#define FULL_TASK_EXAMPLE

#ifdef FULL_TASK_EXAMPLE
const sc_lv_base seq = [](string a) -> string { reverse(a.begin(), a.end()); return a; }(string(
	"00001011"
)).c_str();
sc_logic other_values('x');
int seqIndex = 0;
void Numgen::generate(){
	if (seqIndex < 8) {
		out.write(seq[seqIndex++]);
	}
	else {
		out.write(other_values);
	}
}
#else
void Numgen::generate(){
  static sc_logic a = '0';
  out.write(a = ~a);
}
#endif