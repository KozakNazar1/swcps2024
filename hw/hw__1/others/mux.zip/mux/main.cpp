#include "systemc.h"
#include "numgen.h"
#include "mux.h"
#include "display.h"

int sc_main(int ac, char* av[]) {
	const sc_logic const_in2 = '1';
	const sc_logic const_in1 = '0';
	sc_signal<sc_logic> in2;
	sc_signal<sc_logic> in1;

	sc_signal<sc_logic> sel;
	sc_signal<sc_logic> out;
	sc_clock clk("Clock", 1, 0.5, 0.0);

	in2.write(1); // in2.write(const_in2);
	in1.write(0); // in2.write(const_in1);

	Numgen numgen("numgen");
	numgen(sel, clk);

	Mux mux("mux");
	mux.in2(in2);
	mux.in1(in1);
	mux.sel(sel);
	mux.out(out);

	Display display("display"); 
	display(clk, in2, in1, sel, out);

	sc_trace_file* tf = sc_create_vcd_trace_file("counter_tracefile"); // (=> out\build\Debug)
	sc_trace(tf, in2, "in2");
	sc_trace(tf, in1, "in1");
	sc_trace(tf, sel, "sel");
	sc_trace(tf, out, "out");

	sc_start(clk, 9);

	sc_close_vcd_trace_file(tf);

	return 0;
}