#include "systemc.h"
#include "display.h"

void Display::print(){
    static int rise_edge_event_index = 0;
    cout << "(rise edge event index :" << rise_edge_event_index++ << ") :: ";
    cout << "in2 = " << in2.read() << " "
         << "in1 = " << in1.read() << " "
         << "sel = " << sel.read() << " "
         << "out = " << out.read() 
         << endl;
} 

